// This is a JavaScript file

       var apikey="55cbf24145fecb90e4af8644460ef3ad4e46af0d21aa77e672eb4b5918702091";
       var clientkey="f39aaf8226e7e5e2c644ade99f4161adb3960fe46e6bf86448a004d123adf13f";
       var ncmb = new NCMB(apikey,clientkey);
       
      function oncall(ele){
        var questionone,questiontwo,questionthree,questionfour,questionfive,questionsix,questionseven;
        var id=ele.id;
        var value=ele.value;
        console.log(id);
        console.log(value);
        if(id=="questionone"){
          questionone=value;
          sessionStorage.setItem("questionone",questionone);
        }else{
          if(id=="questiontwo"){
            questiontwo=value;
            sessionStorage.setItem("questiontwo",questiontwo);
        }else{
           if(id=="questionthree"){
            questionthree=value;
            sessionStorage.setItem("questionthree",questionthree);
        }else{
           if(id=="questionfour"){
            questionfour=value;
            sessionStorage.setItem("questionfour",questionfour);
        }else{
           if(id=="questionfive"){
            questionfive=value;
            sessionStorage.setItem("questionfive",questionfive);
        }else{
           if(id=="questionsix"){
            questionsix=value;
           sessionStorage.setItem("questionsix",questionsix);
        }else{
          questionseven=value;
          sessionStorage.setItem("questionseven",questionseven);
        }
        }
        }
        }
        }
        } 
       }
       
       //[「結果を見るボタン」をクリックするとdijob()
       function dojob(){
         var one=sessionStorage.getItem("questionone");
        var two=sessionStorage.getItem("questiontwo");
        var three=sessionStorage.getItem("questionthree");
        var four=sessionStorage.getItem("questionfour");
        var five=sessionStorage.getItem("questionfive");
        var six=sessionStorage.getItem("questionsix");
        var seven=sessionStorage.getItem("questionseven");
        var resu=[one,two,three,four,five,six,seven];
       console.log(resu);
       
      // for(i=1;i<resu.length;i++){
        // if(resu[i]=="")alert(resu[i]+"番は選択していません！");}

           var nekoneko = ncmb.DataStore("nekoneko");
            nekoneko.fetchAll()
            .then(function(results){
            for (var i=0; i<results.length;i++) {
                 var object = results[i];
              console.log(object.name);
              var rone=object.get("questionone");
              var rtwo=object.get("questiontwo");
              var rthree=object.get("questionthree");
              var rfour=object.get("questionfour");
              var rfive=object.get("questionfive");
              var rsix=object.get("questionsix");
              var rseven=object.get("questionseven");
              var ressheet=[rone,rtwo,rthree,rfour,rfive,rsix,rseven];
             console.log(ressheet);

              var count=[0,0,0,0,0,0,0];
             var j=0;
              while(j<7){
                 if(resu[j] ==ressheet[j]){
                  count[i]++;
                  j++;
                }else{
                  j++;
                }
              }
               console.log(i+1+"の値は"+count[i]);
                if(i==0){
                sessionStorage.setItem("トラ柄",count[0]);
              }
                 if(i==1){
                sessionStorage.setItem("黒",count[1]);
              }
                if(i==2){
                sessionStorage.setItem("白",count[2]);
              }
                 if(i==3){
                sessionStorage.setItem("三毛",count[3]);
              }
                if(i==4){
               sessionStorage.setItem("グレー",count[4]);
              }
               if(i==5){
                sessionStorage.setItem("白黒",count[5]);
              }
              if(i==6){
                 sessionStorage.setItem("その他",count[6]);
              }
              }

                //nekonekoテーブルと何個合っているかをチェック
             count[0]=sessionStorage.getItem("トラ柄");
              count[1]=sessionStorage.getItem("黒");
              count[2]=sessionStorage.getItem("白");
              count[3]=sessionStorage.getItem("三毛");
               count[4]=sessionStorage.getItem("グレー");
               count[5]=sessionStorage.getItem("白黒");
               count[6]=sessionStorage.getItem("その他");
                console.log(count);
               var m=count[0];
              var partone=[];
              if(count[1]>=m){ m=count[1];}
              if(count[2]>=m){m=count[2];}
                 if(count[3]>=m){ m=count[3];}
                   if(count[4]>=m){ m=count[4];}
                     if(count[5]>=m){ m=count[5];}
                     if(count[6]>=m){ m=count[6]; }       
          console.log(m);
          //合っている数が一番多いやつを選らんで来る
          if(count[0]==m){partone[0]="トラ柄";document.getElementById("tora").style.display="block";}
          if(count[1]==m){partone[1]="黒";document.getElementById("kuro").style.display="block";}
          if(count[2]==m){ partone[2]="白";document.getElementById("siro").style.display="block";}
          if(count[3]==m){ partone[3]="三毛";document.getElementById("mike").style.display="block";}
          if(count[4]==m){ partone[4]="グレー";document.getElementById("gurei").style.display="block";}
          if(count[5]==m){partone[5]="白黒"; document.getElementById("sirokuro").style.display="block";}
          if(count[6]==m){partone[6]="その他";document.getElementById("sonota").style.display="block";}
          var x = partone.filter(v => v);
          
         // SNSボタンを追加するエリア
var snsArea = document.getElementById('sns-area');
 
// シェア時に使用する値
var shareUrl = ' 猫診断アプリ'; // 現在のページURLを使用する場合 location.href;
var shareText ='あなたに合う猫は'+x+'です。'; // 現在のページタイトルを使用する場合 document.title;
 
generate_share_button(snsArea, shareUrl, shareText);
 
// シェアボタンを生成する関数
function generate_share_button(area, url, text) {
    // シェアボタンの作成
    var twBtn = document.createElement('div');
    twBtn.className = 'twitter-btn';
    // 各シェアボタンのリンク先
    var twHref = 'https://twitter.com/share?text='+encodeURIComponent(text)+'&url='+encodeURIComponent(url);
 
    // シェアボタンにリンクを追加<img src="../img/twitter@0.5x.png" alt="twitter">// 'onclick="popupWindow(this.href); return false;"'
    var clickEv ='maimaipi';
    var twLink = '<a href="' + twHref + '" ' + clickEv + '>twitter</a>';
    twBtn.innerHTML = twLink;
 
    // シェアボタンを表示
    area.appendChild(twBtn);
}
        var jieguo=x.toString();
       //var  jieguo =x.join('');
       
       //最終結果をmobile backendに保存する
       sessionStorage.setItem("結果",jieguo);
       var keka=sessionStorage.getItem("結果");
          var UserTable=ncmb.DataStore("UserTable");
             var user=new UserTable();
            user.set("questionone",one)
                 .set("questiontwo",two)
                 .set("questionthree",three)
                 .set("questionfour",four)
                 .set("questionfive",five)
                 .set("questionsix",six)
                 .set("questionseven",seven)
                 .set("keka",keka)
                 .save()
                 .then(function(user){
                 })
                 .catch(function(err){
                 });
             })
         .catch(function(err){
            console.log(err);
          });
          }




